#!/usr/bin/env python
# coding: utf-8

# In[3]:


import cv2
import cvzone
from cvzone.SelfiSegmentationModule import SelfiSegmentation
import os

cap=cv2.VideoCapture(r"C:\Users\divya\Downloads\image.jpeg")
cap.set(3, 640)
cap.set(4, 480)

segmentor=SelfiSegmentation()
imgBg=cv2.imread(r"C:\Users\divya\OneDrive\Desktop\assignment\image_processing\image_processing\Real-Time_Background_remover\image\1.jpg")

while True:
    success, img = cap.read()
    img_out=segmentor.removeBG(img,imgBg,threshold=0.8)

    imgStacked= cvzone.stackImages([img,img_out],2,1)

    cv2.imshow("Image",imgStacked)


    cv2.waitKey(1)


# In[ ]:




